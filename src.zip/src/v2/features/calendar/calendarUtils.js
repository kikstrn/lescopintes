export const CALENDAR_ITEM_TYPES = {
    EVENT: "event",
    BIKE: "bike",
    TENNIS: "tennis",
  };
  
  export const CALENDAR_TYPE_LABELS = {
    event: "Événement",
    bike: "Sortie vélo",
    tennis: "Match de tennis",
  };
  
  export const CALENDAR_WEEKDAYS = [
    "Lun",
    "Mar",
    "Mer",
    "Jeu",
    "Ven",
    "Sam",
    "Dim",
  ];
  
  const MONTHS = [
    "janvier",
    "février",
    "mars",
    "avril",
    "mai",
    "juin",
    "juillet",
    "août",
    "septembre",
    "octobre",
    "novembre",
    "décembre",
  ];
  
  export function toDate(value) {
    if (!value) return null;
  
    if (value instanceof Date) {
      return Number.isNaN(value.getTime())
        ? null
        : new Date(value);
    }
  
    if (typeof value === "string") {
      const shortIso = value.match(
        /^(\d{4})-(\d{2})-(\d{2})$/,
      );
  
      if (shortIso) {
        const [, year, month, day] = shortIso;
  
        return new Date(
          Number(year),
          Number(month) - 1,
          Number(day),
        );
      }
    }
  
    const date = new Date(value);
  
    return Number.isNaN(date.getTime())
      ? null
      : date;
  }
  
  export function toDateKey(value) {
    const date = toDate(value);
  
    if (!date) return null;
  
    return [
      date.getFullYear(),
      String(date.getMonth() + 1).padStart(2, "0"),
      String(date.getDate()).padStart(2, "0"),
    ].join("-");
  }
  
  export function formatMonthTitle(value) {
    const date = toDate(value) ?? new Date();
  
    return `${MONTHS[date.getMonth()]} ${date.getFullYear()}`;
  }
  
  export function formatLongDate(value) {
    const date = toDate(value);
  
    if (!date) return "";
  
    return new Intl.DateTimeFormat("fr-FR", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(date);
  }
  
  export function formatTime(value) {
    const date = toDate(value);
  
    if (!date) return "";
  
    const hasTime =
      date.getHours() !== 0 ||
      date.getMinutes() !== 0;
  
    if (!hasTime) return "";
  
    return new Intl.DateTimeFormat("fr-FR", {
      hour: "2-digit",
      minute: "2-digit",
    }).format(date);
  }
  
  export function getMonthStart(value) {
    const date = toDate(value) ?? new Date();
  
    return new Date(
      date.getFullYear(),
      date.getMonth(),
      1,
    );
  }
  
  export function getMonthEnd(value) {
    const date = toDate(value) ?? new Date();
  
    return new Date(
      date.getFullYear(),
      date.getMonth() + 1,
      0,
      23,
      59,
      59,
      999,
    );
  }
  
  export function addMonths(value, amount) {
    const date = toDate(value) ?? new Date();
  
    return new Date(
      date.getFullYear(),
      date.getMonth() + amount,
      1,
    );
  }
  
  export function isSameDay(firstValue, secondValue) {
    const first = toDate(firstValue);
    const second = toDate(secondValue);
  
    if (!first || !second) return false;
  
    return (
      first.getFullYear() === second.getFullYear() &&
      first.getMonth() === second.getMonth() &&
      first.getDate() === second.getDate()
    );
  }
  
  export function isSameMonth(firstValue, secondValue) {
    const first = toDate(firstValue);
    const second = toDate(secondValue);
  
    if (!first || !second) return false;
  
    return (
      first.getFullYear() === second.getFullYear() &&
      first.getMonth() === second.getMonth()
    );
  }
  
  export function buildMonthGrid(monthValue) {
    const monthStart = getMonthStart(monthValue);
    const mondayIndex =
      (monthStart.getDay() + 6) % 7;
  
    const gridStart = new Date(
      monthStart.getFullYear(),
      monthStart.getMonth(),
      1 - mondayIndex,
    );
  
    return Array.from(
      { length: 42 },
      (_, index) => {
        const date = new Date(
          gridStart.getFullYear(),
          gridStart.getMonth(),
          gridStart.getDate() + index,
        );
  
        return {
          date,
          key: toDateKey(date),
          dayNumber: date.getDate(),
          isCurrentMonth: isSameMonth(
            date,
            monthStart,
          ),
          isToday: isSameDay(
            date,
            new Date(),
          ),
        };
      },
    );
  }
  
  function firstValue(source, keys) {
    for (const key of keys) {
      const value = source?.[key];
  
      if (
        value !== undefined &&
        value !== null &&
        value !== ""
      ) {
        return value;
      }
    }
  
    return null;
  }
  
  function resolveDate(source) {
    const dateValue = firstValue(source, [
      "starts_at",
      "start_at",
      "start_date",
      "scheduled_at",
      "scheduled_date",
      "event_date",
      "ride_date",
      "match_date",
      "played_at",
      "date",
    ]);
  
    const date = toDate(dateValue);
  
    if (!date) return null;
  
    const timeValue = firstValue(source, [
      "time",
      "start_time",
      "scheduled_time",
    ]);
  
    if (
      typeof timeValue === "string" &&
      /^\d{1,2}:\d{2}/.test(timeValue)
    ) {
      const [hours, minutes] =
        timeValue.split(":");
  
      date.setHours(
        Number(hours),
        Number(minutes),
        0,
        0,
      );
    }
  
    return date;
  }
  
  function memberName(member) {
    return (
      member?.nickname ??
      member?.display_name ??
      member?.full_name ??
      member?.first_name ??
      member?.firstName ??
      member?.name ??
      null
    );
  }
  
  function membersMap(members = []) {
    const map = new Map();
  
    members.forEach((member) => {
      [
        member?.id,
        member?.profile_id,
        member?.user_id,
      ]
        .filter(Boolean)
        .forEach((id) => {
          map.set(String(id), member);
        });
    });
  
    return map;
  }
  
  function resolveName(value, map) {
    if (!value) return null;
  
    if (typeof value === "object") {
      return memberName(
        value.profile ??
        value.member ??
        value.user ??
        value.player ??
        value,
      );
    }
  
    return (
      memberName(map.get(String(value))) ??
      String(value)
    );
  }
  
  function participants(source, map) {
    const raw = firstValue(source, [
      "participants",
      "attendees",
      "event_participants",
      "bike_ride_participants",
      "players",
    ]);
  
    if (!Array.isArray(raw)) return [];
  
    return raw
      .map((item) => {
        if (typeof item === "object") {
          return (
            resolveName(item, map) ??
            resolveName(
              item.profile_id ??
              item.member_id ??
              item.user_id ??
              item.player_id,
              map,
            )
          );
        }
  
        return resolveName(item, map);
      })
      .filter(Boolean);
  }
  
  function normaliseEvent(event, map) {
    const date = resolveDate(event);
  
    if (!date) return null;
  
    return {
      id: `event:${event.id ?? toDateKey(date)}`,
      sourceId: event.id ?? null,
      type: CALENDAR_ITEM_TYPES.EVENT,
      title:
        event.title ??
        event.name ??
        event.label ??
        "Événement",
      date,
      dateKey: toDateKey(date),
      timeLabel: formatTime(date),
      location:
        event.location ??
        event.place ??
        event.address ??
        null,
      description:
        event.description ??
        event.notes ??
        null,
      participants: participants(event, map),
      source: event,
    };
  }
  
  function normaliseBikeRide(ride, map) {
    const date = resolveDate(ride);
  
    if (!date) return null;
  
    const distance =
      ride.distance_km ??
      ride.distance ??
      null;
  
    return {
      id: `bike:${ride.id ?? toDateKey(date)}`,
      sourceId: ride.id ?? null,
      type: CALENDAR_ITEM_TYPES.BIKE,
      title:
        ride.title ??
        ride.name ??
        ride.route_name ??
        (
          distance
            ? `Sortie vélo ${distance} km`
            : "Sortie vélo"
        ),
      date,
      dateKey: toDateKey(date),
      timeLabel: formatTime(date),
      location:
        ride.location ??
        ride.start_location ??
        ride.meeting_point ??
        null,
      description:
        ride.description ??
        ride.notes ??
        null,
      participants: participants(ride, map),
      distance,
      elevation:
        ride.elevation_gain ??
        ride.elevation ??
        ride.d_plus ??
        null,
      source: ride,
    };
  }
  
  function tennisPlayers(match, map) {
    const first = resolveName(
      match.player_one ??
      match.player1 ??
      match.player_a ??
      match.player_one_id ??
      match.player1_id ??
      match.player_a_id,
      map,
    );
  
    const second = resolveName(
      match.player_two ??
      match.player2 ??
      match.player_b ??
      match.player_two_id ??
      match.player2_id ??
      match.player_b_id,
      map,
    );
  
    const direct = [first, second].filter(Boolean);
  
    return direct.length
      ? direct
      : participants(match, map);
  }
  
  function normaliseTennisMatch(match, map) {
    const date = resolveDate(match);
  
    if (!date) return null;
  
    const players = tennisPlayers(
      match,
      map,
    );
  
    return {
      id: `tennis:${match.id ?? toDateKey(date)}`,
      sourceId: match.id ?? null,
      type: CALENDAR_ITEM_TYPES.TENNIS,
      title:
        match.title ??
        match.name ??
        (
          players.length >= 2
            ? `${players[0]} vs ${players[1]}`
            : "Match de tennis"
        ),
      date,
      dateKey: toDateKey(date),
      timeLabel: formatTime(date),
      location:
        match.location ??
        match.court ??
        match.venue ??
        null,
      description:
        match.description ??
        match.notes ??
        null,
      participants: players,
      score:
        match.score ??
        match.score_label ??
        match.result ??
        null,
      source: match,
    };
  }
  
  export function buildCalendarItems({
    events = [],
    bikeRides = [],
    tennisMatches = [],
    members = [],
  } = {}) {
    const map = membersMap(members);
  
    return [
      ...events.map((item) =>
        normaliseEvent(item, map),
      ),
      ...bikeRides.map((item) =>
        normaliseBikeRide(item, map),
      ),
      ...tennisMatches.map((item) =>
        normaliseTennisMatch(item, map),
      ),
    ]
      .filter(Boolean)
      .sort(
        (first, second) =>
          first.date.getTime() -
          second.date.getTime(),
      );
  }
  
  export function groupCalendarItemsByDate(
    items = [],
  ) {
    return items.reduce(
      (groups, item) => {
        const key =
          item.dateKey ??
          toDateKey(item.date);
  
        if (!key) return groups;
  
        groups[key] ??= [];
        groups[key].push(item);
  
        return groups;
      },
      {},
    );
  }
  
  export function getItemsForDate(
    items = [],
    date,
  ) {
    const key = toDateKey(date);
  
    return items.filter(
      (item) =>
        (
          item.dateKey ??
          toDateKey(item.date)
        ) === key,
    );
  }
  
  export function filterItemsByMonth(
    items = [],
    monthValue,
  ) {
    const start = getMonthStart(monthValue);
    const end = getMonthEnd(monthValue);
  
    return items.filter((item) => {
      const date = toDate(item.date);
  
      return (
        date &&
        date >= start &&
        date <= end
      );
    });
  }
  
  export function countItemsByType(
    items = [],
  ) {
    return items.reduce(
      (counts, item) => {
        if (counts[item.type] !== undefined) {
          counts[item.type] += 1;
          counts.total += 1;
        }
  
        return counts;
      },
      {
        total: 0,
        event: 0,
        bike: 0,
        tennis: 0,
      },
    );
  }
  